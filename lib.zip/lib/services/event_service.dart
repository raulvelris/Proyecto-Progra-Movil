import '/models/location.dart';
import '/models/resource.dart';
import '../models/event.dart';

class EventService {
  static const String baseUrl = 'https://tu-api.com/api';

  Future<Event> getEventById(int eventId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final events = await _getMockEvents();
    return events.firstWhere(
      (e) => e.eventId == eventId,
      orElse: () => _createDefaultEvent(),
    );
  }

  Future<List<Event>> getPublicEvents() async {
    await Future.delayed(const Duration(milliseconds: 350));
    return await _getMockEvents();
  }

  Future<List<Event>> getCreatedEvents() async {
    await Future.delayed(const Duration(milliseconds: 350));
    final all = await _getMockEvents();
    return all.where((e) => e.eventId % 2 == 0).toList();
  }

  Future<List<Event>> getAttendedEvents() async {
    await Future.delayed(const Duration(milliseconds: 350));
    final all = await _getMockEvents();
    return all.where((e) => e.isAttending).toList();
  }

  Future<bool> confirmAttendance(int eventId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return true;
  }

  Future<bool> cancelAttendance(int eventId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return true;
  }

  Future<List<Event>> _getMockEvents() async {
    const desc = '''
¡Por primera vez en Perú! Llega el espectáculo oficial en español de los Brainrots Italianos.
Disfruta una mega producción con escenografía y musicales en vivo. 
Podrás ver a Baterina Capuchina, Tralalero Tralala, Tun Tun Sahur, Capuchino Asesino y más... ¡EN DIRECTO!
''';

    return [
      Event(
        eventId: 1,
        title: 'Baile de los Brainrots',
        description: desc,
        startDate: DateTime(2025, 9, 11, 20, 0),
        endDate: DateTime(2025, 9, 11, 23, 0),
        image: 'assets/images/brainrots.jpg',
        eventStatus: 1,
        privacy: 1,
        location: Location(
          locationId: 1,
          address: 'Av de los Precursores 125-127, San Miguel 15088',
          latitude: -12.0775,
          longitude: -77.0930,
          eventId: 1,
        ),
        resources: [
          Resource(
            sharedFileId: 1,
            name: 'Agenda',
            url: 'https://www.ulima.edu.pe/sites/default/files/career/files/malla_ing_sistemas_2025_1.pdf',
            resourceType: 1,
            eventId: 1,
          ),
          Resource(
            sharedFileId: 2,
            name: 'Trailer',
            url: 'https://www.youtube.com/watch?v=-MKFIecXRys',
            resourceType: 2,
            eventId: 1,
          ),
        ],
        isAttending: false,
      ),
      Event(
        eventId: 2,
        title: 'Festival de Música Electrónica',
        description: 'El mejor festival para vibrar con DJs locales e internacionales. Trae bloqueador y buenas vibras.',
        startDate: DateTime(2025, 10, 15, 18, 0),
        endDate: DateTime(2025, 10, 16, 6, 0),
        image: 'assets/images/festival.jpg',
        eventStatus: 1,
        privacy: 1,
        location: Location(
          locationId: 2,
          address: 'Costa Verde, Miraflores',
          latitude: -12.1260,
          longitude: -77.0300,
          eventId: 2,
        ),
        isAttending: false,
      ),
      Event(
        eventId: 3,
        title: 'Conferencia de Tecnología',
        description: 'Charlas sobre IA, nube y buenas prácticas. Networking con cafecito y stickers.',
        startDate: DateTime(2025, 8, 20, 9, 0),
        endDate: DateTime(2025, 8, 20, 17, 0),
        image: 'assets/images/tech.jpg',
        eventStatus: 1,
        privacy: 1,
        location: Location(
          locationId: 3,
          address: 'Centro de Convenciones, San Isidro',
          latitude: -12.0975,
          longitude: -77.0350,
          eventId: 3,
        ),
        isAttending: true,
      ),
    ];
  }

  Event _createDefaultEvent() {
    return Event(
      eventId: 0,
      title: 'Evento no encontrado',
      description: 'El evento solicitado no está disponible',
      startDate: DateTime.now(),
      endDate: DateTime.now().add(const Duration(hours: 2)),
      image: 'assets/images/brainrots.jpg',
      eventStatus: 0,
      privacy: 0,
      isAttending: false,
    );
  }
}
