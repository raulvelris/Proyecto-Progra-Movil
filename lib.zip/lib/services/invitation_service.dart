import 'dart:math';
import 'package:get/get.dart';
import '../models/invitation.dart';

class InvitationService extends GetxService {
  final List<Invitee> _peoplePool = [
    Invitee(id: 1, name: 'Aaron Lobo',   email: 'aaron.lobo@email.com'),
    Invitee(id: 2, name: 'Aaron Tello',  email: 'aaron.tello@email.com'),
    Invitee(id: 3, name: 'Aaron Pérez',  email: 'aaron.perez@email.com'),
    Invitee(id: 4, name: 'Beatriz Silva',email: 'bea.silva@email.com'),
    Invitee(id: 5, name: 'Camila Ramos', email: 'camila.r@email.com'),
    Invitee(id: 6, name: 'Diego Quispe', email: 'd.quispe@email.com'),
    Invitee(id: 7, name: 'Elena Torres', email: 'elena.t@email.com'),
    Invitee(id: 8, name: 'Fiorella Vega',email: 'fio.vega@email.com'),
    Invitee(id: 9, name: 'Gustavo León', email: 'gus.leon@email.com'),
  ];

  final RxMap<int, List<Invitee>> _invitesByEvent = <int, List<Invitee>>{}.obs;

  List<Invitee> peoplePool([String query = '']) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return List.of(_peoplePool);
    return _peoplePool.where((p) => p.name.toLowerCase().contains(q)).toList();
  }

  List<Invitee> invitesForEvent(int eventId) {
    // Accede al RxMap para que Obx detecte cambios
    final _ = _invitesByEvent[eventId];
    return List.of(_invitesByEvent[eventId] ?? _seedEvent(eventId));
  }

  Future<void> updateStatus({
    required int eventId,
    required int inviteeId,
    required InviteStatus status,
  }) async {
    final list = _invitesByEvent[eventId] ?? _seedEvent(eventId);
    final idx = list.indexWhere((i) => i.id == inviteeId);
    if (idx != -1) {
      list[idx].status = status;
      _invitesByEvent[eventId] = List.of(list);
    }
  }

  Future<void> sendInvites({
    required int eventId,
    required List<int> inviteeIds,
  }) async {
    final existing = _invitesByEvent[eventId] ?? _seedEvent(eventId);
    final toAdd = _peoplePool
        .where((p) => inviteeIds.contains(p.id))
        .where((p) => existing.every((e) => e.id != p.id))
        .map((p) => Invitee(id: p.id, name: p.name, email: p.email))
        .toList();

    existing.addAll(toAdd);
    _invitesByEvent[eventId] = List.of(existing);
  }

  List<Invitee> _seedEvent(int eventId) {
    final rand = Random(eventId);
    final base = [
      Invitee(id: 1, name: 'Aaron Lobo',    email: 'aaron.lobo@email.com'),
      Invitee(id: 4, name: 'Beatriz Silva', email: 'bea.silva@email.com'),
      Invitee(id: 6, name: 'Diego Quispe',  email: 'd.quispe@email.com'),
    ];
    for (final p in base) {
      p.status = InviteStatus.values[rand.nextInt(3)];
    }
    _invitesByEvent[eventId] = List.of(base);
    return _invitesByEvent[eventId]!;
  }
}
