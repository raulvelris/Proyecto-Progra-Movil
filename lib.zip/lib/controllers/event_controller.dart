import 'package:get/get.dart';
import 'models/event.dart';
import 'services/event_service.dart';

class EventController extends GetxController {
  EventController({EventService? service})
      : _service = service ?? Get.find<EventService>();

  final EventService _service;

  final RxList<Event> publicEvents = <Event>[].obs;
  final RxList<Event> attendedEvents = <Event>[].obs;
  final RxBool loading = false.obs;

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    loading.value = true;
    final pub = await _service.getPublicEvents();
    publicEvents.assignAll(pub);
    attendedEvents.assignAll(pub.where((e) => e.isAttending).toList());
    loading.value = false;
  }

  Future<void> confirm(int eventId) async {
    await _service.confirmAttendance(eventId);
    _toggleLocal(eventId, true);
  }

  Future<void> cancel(int eventId) async {
    await _service.cancelAttendance(eventId);
    _toggleLocal(eventId, false);
  }

  void _toggleLocal(int id, bool attending) {
    // actualiza en public
    final pi = publicEvents.indexWhere((e) => e.eventId == id);
    if (pi != -1) publicEvents[pi] = _cloneWith(publicEvents[pi], attending);

    // sincroniza attended
    final ai = attendedEvents.indexWhere((e) => e.eventId == id);
    if (attending) {
      if (ai == -1) {
        final src = (pi != -1) ? publicEvents[pi] : attendedEvents.firstWhere((e) => e.eventId == id);
        attendedEvents.add(_cloneWith(src, true));
      } else {
        attendedEvents[ai] = _cloneWith(attendedEvents[ai], true);
      }
    } else {
      if (ai != -1) attendedEvents.removeAt(ai);
    }
  }

  Event _cloneWith(Event e, bool attending) => Event(
        eventId: e.eventId,
        title: e.title,
        description: e.description,
        startDate: e.startDate,
        endDate: e.endDate,
        image: e.image,
        eventStatus: e.eventStatus,
        privacy: e.privacy,
        location: e.location,
        resources: e.resources,
        isAttending: attending,
      );
}
