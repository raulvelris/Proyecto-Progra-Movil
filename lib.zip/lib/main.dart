import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'services/event_service.dart';
import 'event_controller.dart';
// ... tus otros imports

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Env.load();
  await SessionService().init();

  Get.put(EventService());
  Get.put(EventController()); // <-- importante

  runApp(const MyApp());
}
