import 'package:get/get.dart';

class TemplateController extends GetxController {}
