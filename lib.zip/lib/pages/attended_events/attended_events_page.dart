import 'package:flutter/material.dart';
import 'package:get/get.dart';

// ⬅️  Si tu controlador está en lib/event_controller.dart (como en tus capturas)
import '../../event_controller.dart';

// Model y detalles
import '../../models/event.dart';
import '../event_details/event_details_page.dart';

class AttendedEventsPage extends StatelessWidget {
  AttendedEventsPage({super.key});

  // Asegúrate de haber hecho Get.put(EventController()) en main.dart
  final EventController controller = Get.find<EventController>();

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final items = controller.attendedEvents;

      if (items.isEmpty) {
        return const Center(child: Text('Aún no asistes a eventos'));
      }

      return ListView.separated(
        itemCount: items.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final e = items[i];
          return _EventTile(
            event: e,
            // ⬅️  Navegamos pasando el Event, NO eventId
            onTap: () => Get.to(() => EventDetailsPage(event: e)),
            trailing: TextButton(
              onPressed: () => controller.cancel(e.eventId),
              child: const Text('Cancelar'),
            ),
          );
        },
      );
    });
  }
}

class _EventTile extends StatelessWidget {
  const _EventTile({
    required this.event,
    required this.onTap,
    this.trailing,
  });

  final Event event;
  final VoidCallback onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: const Icon(Icons.event_available),
      title: Text(event.title),
      subtitle: Text(event.location?.address ?? ''),
      trailing: trailing,
    );
  }
}
