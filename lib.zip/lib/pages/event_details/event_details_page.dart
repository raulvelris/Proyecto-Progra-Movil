// al inicio del archivo:
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../models/event.dart';
import '../../event_controller.dart';

class EventDetailsPage extends StatelessWidget {
  const EventDetailsPage({super.key, required this.event});
  final Event event;

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<EventController>();

    // ... tu UI; usa "event" directamente ...
    // y para confirmar/cancelar:
    // controller.confirm(event.eventId);
    // controller.cancel(event.eventId);
    return Scaffold(
      appBar: AppBar(title: Text(event.title)),
      body: Center(child: Text(event.description)),
    );
  }
}
