import 'package:get/get.dart';

class CreatedEventsController extends GetxController {}
