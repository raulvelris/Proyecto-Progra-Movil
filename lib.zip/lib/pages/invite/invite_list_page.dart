import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../models/invitation.dart';
import '../../services/invitation_service.dart';

class InviteListPage extends StatelessWidget {
  InviteListPage({super.key});

  final _svc = Get.find<InvitationService>();

  @override
  Widget build(BuildContext context) {
    final int eventId = Get.arguments['eventId'] as int;

    return Scaffold(
      appBar: AppBar(title: const Text('Lista de invitados')),
      body: Obx(() {
        final invites = _svc.invitesForEvent(eventId);
        if (invites.isEmpty) {
          return const Center(child: Text('Aún no hay invitados.'));
        }
        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: invites.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) => _InviteTile(
            invitee: invites[i],
            onChange: (status) => _svc.updateStatus(
              eventId: eventId,
              inviteeId: invites[i].id,
              status: status,
            ),
          ),
        );
      }),
    );
  }
}

class _InviteTile extends StatelessWidget {
  const _InviteTile({required this.invitee, required this.onChange});

  final Invitee invitee;
  final ValueChanged<InviteStatus> onChange;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(child: Text(invitee.initials)),
      title: Text(invitee.name),
      subtitle: Text(invitee.email),
      trailing: GestureDetector(
        onTap: () async {
          final picked = await showModalBottomSheet<InviteStatus>(
            context: context,
            builder: (_) => _StatusPicker(current: invitee.status),
          );
          if (picked != null) onChange(picked);
        },
        child: Chip(
          label: Text(invitee.status.label),
          backgroundColor: invitee.status.color.withOpacity(.12),
          labelStyle: TextStyle(color: invitee.status.color),
        ),
      ),
    );
  }
}

class _StatusPicker extends StatelessWidget {
  const _StatusPicker({required this.current});
  final InviteStatus current;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: InviteStatus.values.map((s) {
          return ListTile(
            leading: Icon(Icons.circle, color: s.color),
            title: Text(s.label),
            trailing: s == current ? const Icon(Icons.check) : null,
            onTap: () => Navigator.pop(context, s),
          );
        }).toList(),
      ),
    );
  }
}
