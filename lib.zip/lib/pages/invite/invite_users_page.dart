import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../services/invitation_service.dart';

class InviteUsersPage extends StatefulWidget {
  const InviteUsersPage({super.key});
  @override
  State<InviteUsersPage> createState() => _InviteUsersPageState();
}

class _InviteUsersPageState extends State<InviteUsersPage> {
  final _svc = Get.find<InvitationService>();
  final _controller = TextEditingController();
  final Set<int> _selected = <int>{};
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final int eventId = Get.arguments['eventId'] as int;
    final people = _svc.peoplePool(_query);

    return Scaffold(
      appBar: AppBar(title: const Text('Invitar usuarios')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                hintText: 'Buscar',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: people.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final p = people[i];
                final checked = _selected.contains(p.id);
                return ListTile(
                  leading: CircleAvatar(child: Text(p.initials)),
                  title: Text(p.name),
                  trailing: Checkbox(
                    value: checked,
                    onChanged: (_) {
                      setState(() {
                        checked ? _selected.remove(p.id) : _selected.add(p.id);
                      });
                    },
                  ),
                  onTap: () {
                    setState(() {
                      checked ? _selected.remove(p.id) : _selected.add(p.id);
                    });
                  },
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton(
                  onPressed: _selected.isEmpty
                      ? null
                      : () async {
                          await _svc.sendInvites(
                            eventId: eventId,
                            inviteeIds: _selected.toList(),
                          );
                          if (!mounted) return;
                          Get.back();
                          Get.snackbar('Invitaciones',
                              'Enviadas a ${_selected.length} usuario(s)');
                        },
                  child: const Text('Enviar invitación'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
