import 'package:flutter/material.dart';

enum InviteStatus { pending, accepted, rejected }

extension InviteStatusX on InviteStatus {
  String get label {
    switch (this) {
      case InviteStatus.accepted:
        return 'Aceptó';
      case InviteStatus.rejected:
        return 'Rechazó';
      case InviteStatus.pending:
      default:
        return 'Sin respuesta';
    }
  }

  Color get color {
    switch (this) {
      case InviteStatus.accepted:
        return Colors.green;
      case InviteStatus.rejected:
        return Colors.redAccent;
      case InviteStatus.pending:
      default:
        return Colors.orange;
    }
  }
}

class Invitee {
  final int id;
  final String name;
  final String email;
  InviteStatus status;

  Invitee({
    required this.id,
    required this.name,
    required this.email,
    this.status = InviteStatus.pending,
  });

  String get initials {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return '??';
    final first = parts.first.isNotEmpty ? parts.first[0] : '';
    final last = parts.length > 1 && parts.last.isNotEmpty ? parts.last[0] : '';
    return (first + last).toUpperCase();
  }
}
